package com.fis.accountmanagement.beans;


public class Accounts {
	
	//these being the names of member variables to store info
	// they are all declared private. but we use public methods to access them (getters and setters)
	// this is done to implement encapsulation
	private long accNo;
	private String custName;
	private long mobile;
	private String accType;
	private String branch;
	private double balance;
//	private List<Transactions> transaction;
	@Override
	public String toString() {
		return "[Account Number=" + accNo + ", Customer Name=" + custName + ", Mobile=" + mobile + ", Account Type=" + accType
				+ ", Branch=" + branch + ", Balance=" + balance + "]";
	}
	// constructor for account details initialization
	public Accounts(long accNo, String custName, long mobile, String accType, String branch, double balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.mobile = mobile;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
	}
	// default constructor
	public Accounts() {
	}
	/**
	 * @return the accNo
	 */
	// getters and setters
	//encapsulation is the principle of OOPS that gets implemented using getters and setters 
	
	
	// function to get the acc number
	public long getAccNo() {
		return accNo;
	}
	/**
	 * @param accNo the accNo to set
	 */
    // setter to set the acc number
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	/**
	 * @return the custName
	 */
	// getter function to get the name of the customer
	public String getCustName() {
		return custName;
	}
	/**
	 * @param custName the custName to set
	 */
	
	// setter function to set the name of the customer
	public void setCustName(String custName) {
		this.custName = custName;
	}
	/**
	 * @return the mobile
	 */
	
	//getter function to get the mobile number 
	public long getMobile() {
		return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	
	// setter function to set the mobile number
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return the accType
	 */
	// getter function to get the type of the account
	public String getAccType() {
		return accType;
	}
	/**
	 * @param accType the accType to set
	 */
	// setter function to set the type of the account
	public void setAccType(String accType) {
		this.accType = accType;
	}
	/**
	 * @return the branch
	 */
	
	// getter function to get the type of the account
	public String getBranch() {
		return branch;
	}
	/**
	 * @param branch the branch to set
	 */
	
	// setter function to set the type of the account
	public void setBranch(String branch) {
		this.branch = branch;
	}
	/**
	 * @return the balance
	 */
	
	//getter function to get the balance of the account
	public double getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	// setter function to set the balance of the account
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
