// accountClientRepo.Java
package com.fis.accountmanagement.repo;

import com.fis.accountmanagement.beans.Accounts;
import com.fis.accountmanagement.exceptions.AccountNotFound;
import com.fis.accountmanagement.exceptions.NotEnoughBalance;

// Interface defining methods in order to interact with account data
public interface AccountClientRepo {
	
	//method for adding an account
	public abstract String addAccount(Accounts account);

	 // method to get a specific account using its account number 
	public abstract Accounts getAccount(long getAcc) throws AccountNotFound;
	
	// method to withdraw from the balance
	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;
    // method to deposit money into the account
	public abstract void depositIntoBalance(long getAcc, double depositAmount);
}
