// TransServiceRepo.java
package com.fis.accountmanagement.repo;

import java.util.ArrayList;

import com.fis.accountmanagement.beans.Transactions;

// Interface defining methods for interacting with transaction data
public interface TransServiceRepo {
	
	// Method to add a transaction (NEFT, RTGS, IMPS, etc.)
	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transactions transaction);
	
	// Method to get transaction details for a specific account number
	public abstract ArrayList<String> getTransForAccNo(Transactions transaction, long showTransAccNo);

}
